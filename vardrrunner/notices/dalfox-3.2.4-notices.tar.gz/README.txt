Dalfox 3.2.4 dependency notices and source

This archive accompanies the pinned Dalfox binary without changing it. It
retains upstream legal texts and attribution references for the exact tagged
Cargo.lock. Optional and other-target dependencies may be included. It is inert
legal/source data and is never extracted or executed by Runner.

manifest.json maps each original license declaration, source URL/checksum and
notice to its delivered bytes. sources/ contains the four unmodified MPL-2.0
crate archives, verified against Cargo.lock. The same license texts and source
headers remain in those source archives. Other exact dependency sources are
available at the recorded immutable version URLs with their checksums.

The upstream Android-only verifier crate does not contain full grant text; this
platform is not part of Runner's supported desktop distribution. Its parent
manifest's target condition is retained under dalfox/. No missing grant has
been invented. This archive does not determine which optional dependencies an
upstream binary links or constitute complete toolchain/base-image source.
