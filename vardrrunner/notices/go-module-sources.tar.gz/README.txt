Go module source delivery

This inert archive retains 17 exact original module source versions, their
module metadata, Go module checksums and SHA-256 file hashes. Original license,
notice and copyright files remain inside each source ZIP. Files are neither
extracted nor executed by the application. SHA256SUMS verifies delivered bytes.

The collection includes versions referenced by existing tool/runtime notice
collections, including cache supersets and dual-licensed material. Inclusion is
not proof of final binary linkage or selection of one branch of a dual license.
The corrected LDAP module is included with its upstream MIT license. No old GPL
LDAP source is added. Modified local dependency forks have separate source and
patch provenance; this original-source archive does not replace those records.

This covers the retained module versions, not every Go module, bundled tool,
compiler, native library or operating-system package in the distribution.
